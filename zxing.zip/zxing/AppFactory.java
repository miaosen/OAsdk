package gzpykj.hzpqy.zxing;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.StrictMode;


import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;

import gzpykj.hzpqy.base.AppContext;

/**
 * @Created by eaglesoft.org
 * @author yangjincheng
 * @Date 2015-3-2
 * @Descrition 应用工厂类
 */

public class AppFactory {
	private static String HOST;
	private static int PORT;
	private static String CONTEXT_PATH;
	private static String ACTION_PREFIX;
	private static String VERSION;

	private static String LOG_TAG;
	//数据库名称
	private static String DB_NAME;
	//数据库路径
	private static String DB_PATH;
	//数据库版本号
	private static String DB_VERSION;
	
	private static String LOGGER="true";

	static {
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
				.permitAll().build();
		StrictMode.setThreadPolicy(policy);

		try {
			Properties p = new Properties();
			p.load(AppContext.getInstance(). getAssets().open("application.properties")
					);

			HOST = p.getProperty("host");
			// HOST = "192.168.1.185";
			PORT = Integer.valueOf(p.getProperty("port"));
			CONTEXT_PATH = p.getProperty("contextPath");
			ACTION_PREFIX = p.getProperty("actionPrefix");
			VERSION = p.getProperty("version");
			LOG_TAG = p.getProperty("logTag");
			DB_PATH= p.getProperty("dbPath");
			DB_NAME= p.getProperty("db");
			DB_VERSION= p.getProperty("dbVersion");
			LOGGER= p.getProperty("log");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getHttpRootPath(){
		String url = "http://" +getHost() + ":"+getPort() +
				getContextPath() +
				  getActionPrefix();
		return url;
	}
	
	public static void setLogTag(String logTag) {
		LOG_TAG = logTag;
	}

	public static String getLogTag() {
		return LOG_TAG;
	}

	public static void setHost(String host) {
		HOST = host;
	}

	public static String getHost() {
		return HOST;
	}

	public static void setPort(int port) {
		PORT = port;
	}

	public static int getPort() {
		return PORT;
	}

	public static void setContextPath(String contextPath) {
		CONTEXT_PATH = contextPath;
	}

	public static String getContextPath() {
		return CONTEXT_PATH;
	}

	public static void setActionPrefix(String actionPrefix) {
		ACTION_PREFIX = actionPrefix;
	}

	public static String getActionPrefix() {
		return ACTION_PREFIX;
	}
	

	public static String getDB_PATH() {
		return DB_PATH;
	}

	public static void setDB_PATH(String dB_PATH) {
		DB_PATH = dB_PATH;
	}

	public static String getDB_NAME() {
		return DB_NAME;
	}

	public static void setDB_NAME(String dB_NAME) {
		DB_NAME = dB_NAME;
	}
	
	public static String getDB_VERSION() {
		return DB_VERSION;
	}

	public static void setDB_VERSION(String dB_VERSION) {
		DB_VERSION = dB_VERSION;
	}

	public static String getLOGGER() {
		return LOGGER;
	}

	public static void setLOGGER(String lOGGER) {
		LOGGER = lOGGER;
	}

	/**
	 * 返回当前版本号
	 * 
	 * @return
	 */
	public static String getVersion() {
		return VERSION;
	}

	/**
	 * 判断是否新版本
	 * 
	 * @param version
	 * @return
	 */
	public static boolean isNewVersion(String version) {
		return version.compareTo(VERSION) >= 1;
	}

	public static String getResouceURL(String path) {
		if (path.startsWith("/")) {
			if (getPort() == 80) {
				return "http://" + getHost() + getContextPath() + path;
			}
			return "http://" + getHost() + ":" + getPort() + getContextPath()
					+ path;
		} else {
			return path;
		}
	}

	/**
	 * 获取网落图片资源
	 * 
	 * @param url
	 * @return
	 */
	public static Bitmap getBitmap(String url) {
		URL myFileURL;
		Bitmap bitmap = null;
		
		try {
			myFileURL = new URL(getResouceURL(url));
			BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
		      bitmapOptions.inSampleSize = 4;  
		      bitmapOptions.inPreferredConfig = Bitmap.Config.ALPHA_8;
		      bitmapOptions.inPurgeable = true;  
		      bitmapOptions.inInputShareable = true; 
			// 获得连接
			HttpURLConnection conn = (HttpURLConnection) myFileURL
					.openConnection();
			// 设置超时时间为6000毫秒，conn.setConnectionTiem(0);表示没有时间限制
			conn.setConnectTimeout(6000);

			conn.setRequestMethod("GET");
			// 连接设置获得数据流
			conn.setDoInput(true);
			// 是否使用缓存
			conn.setUseCaches(true);
			// 这句可有可无，没有影响
			// conn.connect();
			// 得到数据流
			if (conn.getResponseCode() == 200) {
				InputStream is = conn.getInputStream();
				// 解析得到图片
				bitmap = BitmapFactory.decodeStream(is, null, bitmapOptions);
				// 关闭数据流
				is.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return bitmap;

	}




	public static int getLayoutByName(Context context, String name) {
		return getResounceByName(context, "layout", name);
	}

	public static int getIdByName(Context context, String name) {
		return getResounceByName(context, "id", name);
	}

	public static int getDrawableByName(Context context, String name) {
		return getResounceByName(context, "drawable", name);
	}

	public static int getRawByName(Context context, String name) {
		return getResounceByName(context, "raw", name);
	}

	public static int getColorByName(Context context, String name) {
		return getResounceByName(context, "color", name);
	}

	public static String getStringByName(Context context, String name) {
		return context.getResources().getString(
				getResounceByName(context, "string", name));
	}

	/**
	 * 通过名称获取资源ID
	 * 
	 * @param context
	 * @param restype
	 * @param name
	 * @return
	 */
	public static int getResounceByName(Context context, String restype,
										String name) {
		String packageName = context.getPackageName();
		Class r = null;
		int id = 0;
		try {
			r = Class.forName(packageName + ".R");

			Class[] classes = r.getClasses();
			Class desireClass = null;

			for (int i = 0; i < classes.length; ++i) {
				if (classes[i].getName().split("\\$")[1].equals(restype)) {
					desireClass = classes[i];
					break;
				}
			}

			if (desireClass != null) {
				Field field = desireClass.getField(name);
				if (field != null)
					id = field.getInt(desireClass);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		}

		return id;
	}

	/**
	 * 通过名称返回资源ID
	 * 
	 * @param packageName
	 * @param restype
	 * @param name
	 * @return
	 */
	public static int getResounceByName(String packageName, String restype,
										String name) {
		Class r = null;
		int id = 0;
		try {
			r = Class.forName(packageName + ".R");

			Class[] classes = r.getClasses();
			Class desireClass = null;

			for (int i = 0; i < classes.length; ++i) {
				if (classes[i].getName().split("\\$")[1].equals(restype)) {
					desireClass = classes[i];
					break;
				}
			}

			if (desireClass != null) {
				Field field = desireClass.getField(name);
				if (field != null)
					id = field.getInt(desireClass);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		}

		return id;
	}
	
	/**
	 * 通过资源ID获取字段名称
	 * @param context
	 * @param name
	 * @return
	 */
	public static String getNameById(Context context,
									 int id) {
		String packageName = context.getPackageName();
		Class r = null;
		String idName=null;
		try {
			r = Class.forName(packageName + ".R");
			Class[] classes = r.getClasses();
			Class desireClass = null;
			for (int i = 0; i < classes.length; ++i) {
				//L.info("classes[i].getName()========="+classes[i].getName());
				if (classes[i].getName().split("\\$")[1].equals("id")) {
					desireClass = classes[i];
					break;
				}
			}
			if (desireClass != null) {
				Field field[]=desireClass.getFields();
				for (int i = 0; i < field.length; i++) {
					//L.info("field[i].getName()========="+field[i].getName());
					if(field[i].getInt(desireClass)==id){
						idName=field[i].getName();
					}
				}
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		//L.info("idName========="+idName);
		return idName;
	}


	/**
	 * 获取手机所有连接管理对象（包括对wi-fi,net等连接的管理）
	 * 
	 * @param context
	 * @return
	 */
	public static boolean checkNet(Context context) {
		try {
			ConnectivityManager connectivity = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivity != null) {
				// 获取网络连接管理的对象
				NetworkInfo info = connectivity.getActiveNetworkInfo();
				if (info != null && info.isConnected()) {
					// 判断当前网络是否已经连接
					if (info.getState() == NetworkInfo.State.CONNECTED) {
						return true;
					}
				}
			}
		} catch (Exception e) {
		}
		return false;
	}
}
