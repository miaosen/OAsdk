package gzpykj.hzpqy.zxing;

/**
 * @Created by eaglesoft.org
 * @author yangjincheng
 * @Date 2015年3月17日
 * @Description Activity配置类（仅限于继承了BaseActivity类及其子类使用）
 */
public class ActivityConfig {
	protected Object layout;
	protected String headerText;
	protected String actionClass;
	protected boolean headerDisabled;

	public Object getLayout() {
		return layout;
	}

	public void setLayout(Object layout) {
		this.layout = layout;
	}

	public String getHeaderText() {
		return headerText;
	}

	public void setHeaderText(String headerText) {
		this.headerText = headerText;
	}

	public String getActionClass() {
		return actionClass;
	}

	public void setActionClass(String actionClass) {
		this.actionClass = actionClass;
	}

	public boolean isHeaderDisabled() {
		return headerDisabled;
	}

	public void setHeaderDisabled(boolean headerDisabled) {
		this.headerDisabled = headerDisabled;
	}

}
