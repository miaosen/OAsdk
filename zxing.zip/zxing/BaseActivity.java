package gzpykj.hzpqy.zxing;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Map;

/**
 * @Created by eaglesoft.org
 * @author yangjincheng
 * @Date 2015-3-9
 * @Descrition Eagle框架下的Activity基类，内建的一些常用的Activity操作方法及Activity堆栈的管理
 */
public abstract class BaseActivity<T> extends Activity {
	private final static String DEFAULT_PREFS_NAME = "_DEFAULT_PREFS";
	private Map<String, byte[]> imageCache;
	protected Activity context;
	private SharedPreferences sp;
	protected T config;

	protected TextView titleBarHeader;
	protected Button titleBarBackBtn;

	public BaseActivity() {
		super();
		this.context = this;
		//ActivityManager.getInstance().addActivity(this);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		try {
			config = (T) getGenericType().newInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}

		init(config);

		ActivityConfig ac = ((ActivityConfig) config);

		if (ac.getLayout() instanceof Integer) {
			setContentView((Integer) ac.getLayout());
		} else {
			setContentView(AppFactory.getLayoutByName(context,
					(String) ac.getLayout()));
		}

		ready(config);

		if (!ac.isHeaderDisabled()) {

			String headerText = ac.getHeaderText();

			//titleBarBackBtn.setOnClickListener(new OnClickListener() {
            //
			//	@Override
			//	public void onClick(View v) {
			//		back();
			//	}
			//});
		}

	}

	public abstract void init(T config);

	public abstract void ready(T config);

	/**
	 * 返回用户偏好实例
	 * 
	 * @return
	 */
	public SharedPreferences getSharedPreferences() {
		if (sp == null) {
			sp = this.context.getSharedPreferences(DEFAULT_PREFS_NAME,
					Context.MODE_PRIVATE);
		}
		return sp;
	}




	/**
	 * 提示信息
	 * 
	 * @param message
	 */
	public void toast(String message) {
		Toast.makeText(context, message, Toast.LENGTH_LONG).show();
	}

	/**
	 * 退出软件
	 */
	public void exit() {
		Dialog alertDialog = new AlertDialog.Builder(this)
				.setTitle("退出")
				.setMessage(
						"确定退出"
								+ AppFactory.getStringByName(context,
										"app_name") + "吗？")
				.setIcon(AppFactory.getDrawableByName(context, "ic_launcher"))
				.setPositiveButton("确定", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						finish();
					}
				})
				.setNegativeButton("取消", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.cancel();
					}
				}).create();
		alertDialog.show();
	}

	/**
	 * 返回
	 */
	public void back() {
		finish();
		//ActivityManager am = ActivityManager.getInstance();
		//if (am.activitiesCount() > 1) {
		//	am.finishActivity(context);
		//} else {
		//	exit();
		//}
		// overridePendingTransition(R.anim.slide_in_left,
		// R.anim.slide_out_right);
	}

	/**
	 * 退出系统
	 */
	//@Override
	//public boolean onKeyDown(int keyCode, KeyEvent event) {
	//	if (keyCode == KeyEvent.KEYCODE_BACK) {
	//		back();
	//	}
	//	return false;
	//}


	@SuppressWarnings("rawtypes")
	private Class getGenericType() {
		Class cs = getTargetType(getClass());
		if (cs != null) {
			Type genType = cs.getGenericSuperclass();
			Type[] params = ((ParameterizedType) genType)
					.getActualTypeArguments();
			/*
			 * for (Type type : params) { L.info(type.toString()); }
			 */

			return (Class) params[0];
		}
		return null;
	}

	private Class getTargetType(Class clazz) {
		// L.info(clazz.getName());
		Class pcls = clazz.getSuperclass();
		if (pcls != null) {
			if (pcls.getName().equals(BaseActivity.class.getName())) {
				return clazz;
			} else {
				Class sp = clazz.getSuperclass();
				if (sp != null) {
					return getTargetType(sp);
				}
				return null;
			}
		}
		return null;
	}

	/**
	 * 消毁Activity
	 */
	//public void destroy() {
	//	ActivityManager.getInstance().removeActivity(this);
	//	this.finish();
	//}
}
